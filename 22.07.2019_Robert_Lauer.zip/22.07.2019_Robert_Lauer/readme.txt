README

1. How to show the presentation

Open index.html with your browser like Google Chrome, Firefox or Safari.